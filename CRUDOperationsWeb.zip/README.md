# AWS_microservices_lambda1
Creating a simple microservice architecture using API gateway, Lambda and DynamoDB to perform simple CRUD operations
