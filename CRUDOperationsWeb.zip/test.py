import json

def convert_json_to_dynamodb(json_obj):
  
    # Create a new dictionary to store the converted data
    dynamodb_data = {}

    # Iterate through each key-value pair in the data
    for key, value in json_obj.items():
        # Determine the data type of the value
        if isinstance(value, str):
            data_type = 'S'
        elif isinstance(value, int) or isinstance(value, float):
            data_type = 'N'
        elif isinstance(value, dict):
            data_type = 'M'
        elif isinstance(value, list):
            data_type = 'L'
        else:
            # Use 'S' as the default data type
            data_type = 'S'

        # Add the key-value pair to the new dictionary, with the data type specified
        dynamodb_data[key] = {data_type: value}

    return dynamodb_data




event = {
  'operation': 'update',
  'tableName': 'lambda-apigateway-student_info',
  'payload': {
    'Item': {
      'id': 'tom.hardy@gmail.com',
      'first_name': 'Tommies',
      'last_name': 'Hardies',
      'address': '456 NE Calgary Canada'
    }
  }
}

def convertJsonIntoAttributeUpdateFormat(dictObj, actionType):
    # This function will take in a dict formatted in a certain way and reformat it to add
    # Action and Value keys to pass to dynamoDb to update a record.
    # ActionType cam be PUT, ADD, etc...
    # Keys will be id, first_name, last_name, address.

    formattedDict = {
        'first_name':{
            'Action': actionType,
            'Value': dictObj['first_name']
        },
        'last_name':{
            'Action': actionType,
            'Value': dictObj['last_name']
        },
        'address':{
            'Action': actionType,
            'Value': dictObj['address']
        }
    }

    return formattedDict
        

#Read Item from payload
Item = event['payload']['Item']

key = convert_json_to_dynamodb(Item)
print(convertJsonIntoAttributeUpdateFormat(key, 'PUT'))